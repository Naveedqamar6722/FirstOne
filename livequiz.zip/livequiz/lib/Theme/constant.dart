
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

const PrimaryColor=Color(0xff1565C0);
const SecondaryColor=Color(0xffffffff);
const TertiaryColor=Color(0xffFFA500);
