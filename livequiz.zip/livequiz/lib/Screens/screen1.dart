import 'package:flutter/material.dart';
import 'package:flutter_icons/flutter_icons.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:livequiz/Theme/constant.dart';

class Screen1 extends StatelessWidget {
  const Screen1({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(backgroundColor: PrimaryColor,
        body: Container(
          child: Column(
            children: [
              upperContainer(),
              middleContainer(),
              thirdContainer(),
              fourthContainer(),
            ],
          ),
          decoration: BoxDecoration(gradient: LinearGradient(
              begin: Alignment.topRight, end: Alignment.bottomLeft,
              colors: [Colors.blue[900], PrimaryColor, Colors.blue,])),
        ),
      ),
    );
  }

  Widget upperContainer(){
    return Expanded(flex: 2, child: Container(margin: EdgeInsets.symmetric(horizontal: 15),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(height: 45,width: 45,
            decoration: BoxDecoration(color: Colors.pinkAccent,shape: BoxShape.circle),
            child: Center(child:Icon(AntDesign.logout,color: SecondaryColor,size: 20,),),
          ),
          Column(mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(color: Colors.pinkAccent,height: 40,width: 70,
                child: Center(child: Text('LiVE',style: GoogleFonts.baloo(color: SecondaryColor,fontSize: 25),)),),
              Text('QUIZ',style: TextStyle(color: SecondaryColor,fontSize: 25),)
            ],
          ),
          Container(
            height: 25,
            child: Row(
              children: [
                Icon(AntDesign.user,color: Colors.white,size: 20,),
                SizedBox(width: 5,),
                Text('28.9K',style: TextStyle(color: SecondaryColor),)
              ],
            ),
          ),

        ],
      ),
    ),
    );

  }

  Widget middleContainer(){
    return Expanded(flex:5,child: Container(
      child:Column( mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text('00.02',style: TextStyle(color: SecondaryColor,fontWeight: FontWeight.bold,fontSize: 40),),
          SizedBox(height: 15,),
          middleButton((){}),
        ],
      ),
    ));
  }

  Widget middleButton(Function function){
    return GestureDetector( onTap: (){},
      child: Container(height: 50,width: 120,
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [Colors.deepOrangeAccent,TertiaryColor,Colors.deepOrange]),
            borderRadius: BorderRadius.circular(10),
          ),
          child:Row(mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(FlutterIcons.star_half_alt_faw5s,color: SecondaryColor,size: 20,),
              SizedBox(width: 5,),
              Text('200',style: TextStyle(color: SecondaryColor,fontSize: 20),), SizedBox(width: 5,),
              Icon(FlutterIcons.logo_euro_ion,color: SecondaryColor,size: 20,),
            ],)
      ),
    );
  }


  Widget thirdContainer(){
    return Expanded(flex:5,child: Container(margin: EdgeInsets.symmetric(horizontal: 10),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text('Norwegian artist Edvard Munch'
            ' is famous for painting which iconic piece? What’s the capital of Canada? \n(The Scream)',
            style: TextStyle(color: SecondaryColor,fontWeight: FontWeight.w400,fontSize: 16,letterSpacing: 1),),
        ),
      ),));
  }

  Widget fourthContainer(){
    return Expanded(flex: 1, child: Container(margin: EdgeInsets.symmetric(horizontal: 15),
      child: Align( alignment: Alignment.topLeft,
        child: Container(height: 45,width: 45,
          decoration: BoxDecoration(shape: BoxShape.circle,border: Border.all(color: SecondaryColor)),
          child: Center(child:Icon(FlutterIcons.volume_2_sli,color: SecondaryColor,size: 20,),),
        ),
      ),
    ));
  }
}


