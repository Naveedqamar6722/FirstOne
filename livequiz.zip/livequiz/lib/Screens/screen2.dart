import 'package:flutter/material.dart';
import 'package:flutter_icons/flutter_icons.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:livequiz/Theme/constant.dart';
import 'package:livequiz/Widgets/sliderwidget.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
class Screen2 extends StatefulWidget {
  const Screen2({Key key}) : super(key: key);

  @override
  _Screen2State createState() => _Screen2State();
}

class _Screen2State extends State<Screen2> {
  int selectedRadio;

  @override
  void initState() {
    super.initState();
    selectedRadio=0;
  }

  setselectedRadio(int val){
    setState(() {
      selectedRadio=val;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          child: Column(
            children: [
              upperContainer(),
              middleContainer(),
              bottomContainer(),
            ],
          ),
          decoration: BoxDecoration(gradient: LinearGradient(
              begin: Alignment.topRight, end: Alignment.bottomLeft,
              colors: [Colors.blue[900], PrimaryColor, Colors.blue,])),
        ),
      ),
    );
  }

  Widget upperContainer(){
    return Expanded(flex: 2, child: Container(margin: EdgeInsets.symmetric(horizontal: 15),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Column(mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(color: Colors.pinkAccent,height: 40,width: 70,
                child: Center(child: Text('LiVE',style: GoogleFonts.baloo(color: SecondaryColor,fontSize: 25),)),),
              Text('QUIZ',style: TextStyle(color: SecondaryColor,fontSize: 25),)
            ],
          ),
          CircularPercentIndicator(
            lineWidth: 3.0,
            radius: 50.0,
            animation: true,
            animationDuration: 1000,
            // startAngle: 90.0,
            percent: 0.3,
            center: Text('10',style: TextStyle(color: SecondaryColor,fontWeight: FontWeight.bold,fontSize: 18),),
            circularStrokeCap: CircularStrokeCap.round,
            backgroundColor: SecondaryColor.withOpacity(0.3),
            progressColor: Colors.pinkAccent,
          ),
          Container(
            height: 25,
            child: Row(
              children: [
                Icon(AntDesign.user,color: Colors.white,size: 20,),
                SizedBox(width: 5,),
                Text('28.9K',style: TextStyle(color: SecondaryColor),)
              ],
            ),
          ),
        ],
      ),
    ),
    );
  }

  Widget middleContainer(){
    return Expanded(flex: 10, child: Container(
      margin: EdgeInsets.symmetric(horizontal: 15),
      child: SingleChildScrollView(
        child: Column(
          children: [
            Row(
              children: [
                Expanded(child: SliderWidget()),
                SizedBox(width: 8,),
                Container(height: 47,width: 80,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [Colors.deepOrangeAccent,TertiaryColor,Colors.deepOrange]),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child:Row(mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('200',style: TextStyle(color: SecondaryColor,fontSize: 16),), SizedBox(width: 5,),
                        Icon(FlutterIcons.logo_euro_ion,color: SecondaryColor,size: 16,),
                      ],)
                ),
              ],
            ),
            SizedBox(height: 40,),
            Align( alignment: Alignment.topLeft,
              child: Text('What’s the capital of Canada?',
                style: TextStyle(color: SecondaryColor,fontWeight: FontWeight.w400,fontSize: 16,letterSpacing: 1),),
            ),
            SizedBox(height: 30,),
            Container( margin: EdgeInsets.symmetric(vertical: 5),
              height: 50,width: double.infinity,
              decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.circular(20)),
              child: Row(children: [
                Radio(value: 1,
                  groupValue: selectedRadio,
                  activeColor: PrimaryColor,
                  onChanged: (val){setselectedRadio(val);},
                ),
                Text('Ottawa'),
              ],),
            ),
            Container( margin: EdgeInsets.symmetric(vertical: 5),
              height: 50,width: double.infinity,
              decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.circular(20)),
              child: Row(children: [
                Radio(value: 2,
                  groupValue: selectedRadio,
                  activeColor: PrimaryColor,
                  onChanged: (val){setselectedRadio(val);},
                ),
                Text('Ottawa'),
              ],),
            ),
            Container( margin: EdgeInsets.symmetric(vertical: 5),
              height: 50,width: double.infinity,
              decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.circular(20)),
              child: Row(children: [
                Radio(value: 3,
                  groupValue: selectedRadio,
                  activeColor: PrimaryColor,
                  onChanged: (val){setselectedRadio(val);},
                ),
                Text('Ottawa'),
              ],),
            ),
            Container( margin: EdgeInsets.symmetric(vertical: 5),
              height: 50,width: double.infinity,
              decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.circular(20)),
              child: Row(children: [
                Radio(value: 4,
                  groupValue: selectedRadio,
                  activeColor: PrimaryColor,
                  onChanged: (val){setselectedRadio(val);},
                ),
                Text('Ottawa'),
              ],),
            ),
          ],
        ),
      ),
    ));
  }

  Widget bottomContainer(){
    return Expanded(flex: 1, child: Container(margin: EdgeInsets.symmetric(horizontal: 15),
      child: Row(
        children: [
          Container(height: 40,width: 40,
            decoration: BoxDecoration(shape: BoxShape.circle,
                border: Border.all(color: SecondaryColor),),
            child: Center(child:Icon(FlutterIcons.volume_2_sli,color: SecondaryColor,size: 20,),),
          ),
          SizedBox(width: 5,),
          Expanded(
            child: Container(height: 40,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Row( mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                 Row(
                   children: [
                     Container(
                       height: 30,width: 30,
                       decoration: BoxDecoration(shape: BoxShape.circle, color: PrimaryColor,),
                       child: Icon(FlutterIcons.plus_ent,size: 15,color: SecondaryColor,),
                     ),
                     SizedBox(width: 4,),
                      Text('PUNTI',style: TextStyle(color: SecondaryColor),),
                   ],
                 ),
                  Text('758 ',style: TextStyle(color: SecondaryColor),),
                ],
              ),
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: new LinearGradient(
                  colors: [
                    const Color(0xFF00c6ff),
                    const Color(0xFF0072ff),
                  ],
                  begin: const FractionalOffset(0.0, 0.0),
                  end: const FractionalOffset(1.0, 1.00),
                  stops: [0.0, 1.0],
                  tileMode: TileMode.clamp),
            ),
            ),
          ),
          SizedBox(width: 5,),
          Expanded(
            child: Container(height: 40,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Row( mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          height: 30,width: 30,
                          decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.deepOrange,),
                          child: Icon(FlutterIcons.dot_circle_faw5,size: 15,color: SecondaryColor,),
                        ),
                        SizedBox(width: 4,),
                        Text('POS',style: TextStyle(color: SecondaryColor),),
                      ],
                    ),
                    Text('24.7K',style: TextStyle(color: SecondaryColor),),
                  ],
                ),
              ),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: new LinearGradient(
                    colors: [
                      Colors.orangeAccent.withOpacity(0.7),
                     Colors.deepOrange,
                    ],
                    begin: const FractionalOffset(0.0, 0.0),
                    end: const FractionalOffset(1.0, 1.00),
                    stops: [0.0, 1.0],
                    tileMode: TileMode.clamp),
              ),
            ),
          ),
        ],
      ),
    ));
  }
}
